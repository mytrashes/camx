package com.example.kamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root() } }
    }
}

private fun Context.has(p: String) =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(ctx.has(Manifest.permission.CAMERA)) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = it[Manifest.permission.CAMERA] == true || ctx.has(Manifest.permission.CAMERA) }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    if (granted) CameraScreen() else Box(
        Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center
    ) { Text("Izin kamera diperlukan", color = Color.White) }
}

private suspend fun Context.cameraProvider(): ProcessCameraProvider = suspendCoroutine { c ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ c.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val previewView = remember {
        PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
    }

    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var ratio by remember { mutableIntStateOf(AspectRatio.RATIO_4_3) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var timer by remember { mutableIntStateOf(0) }
    var grid by remember { mutableStateOf(false) }
    var videoMode by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var exposure by remember { mutableFloatStateOf(0f) }

    val imageCapture = remember(ratio) {
        ImageCapture.Builder().setTargetAspectRatio(ratio)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
    }
    val videoCapture = remember {
        VideoCapture.withOutput(
            Recorder.Builder().setQualitySelector(
                QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
            ).build()
        )
    }

    LaunchedEffect(lens, ratio) {
        val provider = ctx.cameraProvider()
        val preview = Preview.Builder().setTargetAspectRatio(ratio).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
        provider.unbindAll()
        camera = provider.bindToLifecycle(
            owner, CameraSelector.Builder().requireLensFacing(lens).build(),
            preview, imageCapture, videoCapture
        )
        exposure = 0f
    }
    LaunchedEffect(flash) { imageCapture.flashMode = flash }
    LaunchedEffect(flash, recording, camera) {
        // senter menyala selama rekam video jika flash = ON
        camera?.cameraControl?.enableTorch(recording != null && flash == ImageCapture.FLASH_MODE_ON)
    }

    fun takePhoto() {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Kamera")
        }
        val o = ImageCapture.OutputFileOptions.Builder(
            ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v
        ).build()
        imageCapture.takePicture(o, ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) =
                    Toast.makeText(ctx, "Foto tersimpan", Toast.LENGTH_SHORT).show()
                override fun onError(e: ImageCaptureException) =
                    Toast.makeText(ctx, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
            })
    }

    fun toggleRecord() {
        val active = recording
        if (active != null) { active.stop(); return }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Kamera")
        }
        val o = MediaStoreOutputOptions.Builder(
            ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(v).build()
        var p = videoCapture.output.prepareRecording(ctx, o)
        if (ctx.has(Manifest.permission.RECORD_AUDIO)) p = p.withAudioEnabled()
        recording = p.start(ContextCompat.getMainExecutor(ctx)) { e ->
            if (e is VideoRecordEvent.Finalize) {
                recording = null
                Toast.makeText(
                    ctx, if (e.hasError()) "Video gagal" else "Video tersimpan", Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun shutter() {
        if (recording != null) { toggleRecord(); return }
        scope.launch {
            for (i in timer downTo 1) { countdown = i; delay(1000) }
            countdown = 0
            if (videoMode) toggleRecord() else takePhoto()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ previewView }, Modifier.fillMaxSize().align(Alignment.Center))

        // gestur: pinch zoom + tap fokus
        Box(
            Modifier.fillMaxSize()
                .pointerInput(camera) {
                    detectTransformGestures { _, _, zoom, _ ->
                        val c = camera ?: return@detectTransformGestures
                        val s = c.cameraInfo.zoomState.value ?: return@detectTransformGestures
                        c.cameraControl.setZoomRatio(
                            (s.zoomRatio * zoom).coerceIn(s.minZoomRatio, s.maxZoomRatio)
                        )
                    }
                }
                .pointerInput(camera) {
                    detectTapGestures { o ->
                        val c = camera ?: return@detectTapGestures
                        val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                    }
                }
        )

        if (grid) Canvas(Modifier.fillMaxSize()) {
            val c = Color.White.copy(alpha = 0.5f)
            for (i in 1..2) {
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width * i / 3, 0f),
                    androidx.compose.ui.geometry.Offset(size.width * i / 3, size.height), 2f)
                drawLine(c, androidx.compose.ui.geometry.Offset(0f, size.height * i / 3),
                    androidx.compose.ui.geometry.Offset(size.width, size.height * i / 3), 2f)
            }
        }

        if (countdown > 0) Text(
            "$countdown", color = Color.White, fontSize = 96.sp, modifier = Modifier.align(Alignment.Center)
        )

        // bar atas
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Chip(when (flash) {
                ImageCapture.FLASH_MODE_ON -> "Flash ON"
                ImageCapture.FLASH_MODE_AUTO -> "Flash AUTO"
                else -> "Flash OFF"
            }) {
                flash = when (flash) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            }
            Chip(if (ratio == AspectRatio.RATIO_4_3) "4:3" else "16:9") {
                ratio = if (ratio == AspectRatio.RATIO_4_3) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3
            }
            Chip(if (timer == 0) "Timer OFF" else "Timer ${timer}s") {
                timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 }
            }
            Chip(if (grid) "Grid ON" else "Grid OFF") { grid = !grid }
        }

        // bar bawah
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val range = camera?.cameraInfo?.exposureState?.exposureCompensationRange
            val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
            if (range != null && range.upper > range.lower) {
                Slider(
                    value = exposure,
                    onValueChange = {
                        exposure = it
                        camera?.cameraControl?.setExposureCompensationIndex(it.toInt())
                    },
                    valueRange = range.lower.toFloat()..range.upper.toFloat(),
                    modifier = Modifier.fillMaxWidth(0.7f)
                )
                Text("EV %.1f".format(exposure * step), color = Color.White, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Text("FOTO", color = if (!videoMode) Color.Yellow else Color.White,
                    modifier = Modifier.clickable(enabled = recording == null) { videoMode = false })
                Text("VIDEO", color = if (videoMode) Color.Yellow else Color.White,
                    modifier = Modifier.clickable(enabled = recording == null) { videoMode = true })
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.width(64.dp))
                Box(
                    Modifier.size(76.dp).border(4.dp, Color.White, CircleShape).padding(8.dp)
                        .background(if (videoMode || recording != null) Color.Red else Color.White, CircleShape)
                        .clickable { shutter() }
                )
                Chip("Putar") {
                    if (recording == null)
                        lens = if (lens == CameraSelector.LENS_FACING_BACK)
                            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 12.sp,
        modifier = Modifier.background(Color(0x66000000), CircleShape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)
    )
}
