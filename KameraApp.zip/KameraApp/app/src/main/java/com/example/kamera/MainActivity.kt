@file:OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)

package com.example.kamera

import android.Manifest
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlin.math.pow
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root() } }
    }
}

private fun Context.has(p: String) =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(ctx.has(Manifest.permission.CAMERA)) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = it[Manifest.permission.CAMERA] == true || ctx.has(Manifest.permission.CAMERA) }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    if (granted) CameraScreen() else Box(
        Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center
    ) { Text("Izin kamera diperlukan", color = Color.White) }
}

private suspend fun Context.cameraProvider(): ProcessCameraProvider = suspendCoroutine { c ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ c.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val previewView = remember {
        PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
    }

    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var ratio by remember { mutableIntStateOf(AspectRatio.RATIO_4_3) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var timer by remember { mutableIntStateOf(0) }
    var grid by remember { mutableStateOf(false) }
    var videoMode by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var exposure by remember { mutableFloatStateOf(0f) }
    var pro by remember { mutableStateOf(false) }
    var isoV by remember { mutableFloatStateOf(0.2f) }
    var shutIdx by remember { mutableIntStateOf(5) }
    var wb by remember { mutableIntStateOf(0) }
    var mf by remember { mutableStateOf(false) }
    var focusV by remember { mutableFloatStateOf(0f) }
    val ranges = remember(camera) { camera?.let { proRanges(it) } }
    var stab by remember { mutableStateOf(false) }
    val st = remember(camera) { camera?.let { stabInfo(it) } }

    val imageCapture = remember(ratio) {
        ImageCapture.Builder().setTargetAspectRatio(ratio)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
    }
    val videoCapture = remember {
        VideoCapture.withOutput(
            Recorder.Builder().setQualitySelector(
                QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
            ).build()
        )
    }

    LaunchedEffect(lens, ratio) {
        val provider = ctx.cameraProvider()
        val preview = Preview.Builder().setTargetAspectRatio(ratio).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
        provider.unbindAll()
        camera = provider.bindToLifecycle(
            owner, CameraSelector.Builder().requireLensFacing(lens).build(),
            preview, imageCapture, videoCapture
        )
        exposure = 0f
    }
    LaunchedEffect(flash) { imageCapture.flashMode = flash }
    LaunchedEffect(camera, ranges, pro, isoV, shutIdx, wb, mf, focusV, stab, st) {
        camera?.let { applyPro(it, ranges, pro, isoV, shutIdx, wb, mf, focusV, stab, st) }
    }
    LaunchedEffect(flash, recording, camera) {
        // senter menyala selama rekam video jika flash = ON
        camera?.cameraControl?.enableTorch(recording != null && flash == ImageCapture.FLASH_MODE_ON)
    }

    fun takePhoto() {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Kamera")
        }
        val o = ImageCapture.OutputFileOptions.Builder(
            ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v
        ).build()
        imageCapture.takePicture(o, ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) =
                    Toast.makeText(ctx, "Foto tersimpan", Toast.LENGTH_SHORT).show()
                override fun onError(e: ImageCaptureException) =
                    Toast.makeText(ctx, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
            })
    }

    fun toggleRecord() {
        val active = recording
        if (active != null) { active.stop(); return }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Kamera")
        }
        val o = MediaStoreOutputOptions.Builder(
            ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(v).build()
        var p = videoCapture.output.prepareRecording(ctx, o)
        if (ctx.has(Manifest.permission.RECORD_AUDIO)) p = p.withAudioEnabled()
        recording = p.start(ContextCompat.getMainExecutor(ctx)) { e ->
            if (e is VideoRecordEvent.Finalize) {
                recording = null
                Toast.makeText(
                    ctx, if (e.hasError()) "Video gagal" else "Video tersimpan", Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun shutter() {
        if (recording != null) { toggleRecord(); return }
        scope.launch {
            for (i in timer downTo 1) { countdown = i; delay(1000) }
            countdown = 0
            if (videoMode) toggleRecord() else takePhoto()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ previewView }, Modifier.fillMaxSize().align(Alignment.Center))

        // gestur: pinch zoom + tap fokus
        Box(
            Modifier.fillMaxSize()
                .pointerInput(camera) {
                    detectTransformGestures { _, _, zoom, _ ->
                        val c = camera ?: return@detectTransformGestures
                        val s = c.cameraInfo.zoomState.value ?: return@detectTransformGestures
                        c.cameraControl.setZoomRatio(
                            (s.zoomRatio * zoom).coerceIn(s.minZoomRatio, s.maxZoomRatio)
                        )
                    }
                }
                .pointerInput(camera) {
                    detectTapGestures { o ->
                        if (pro && mf) return@detectTapGestures
                        val c = camera ?: return@detectTapGestures
                        val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                    }
                }
        )

        if (grid) Canvas(Modifier.fillMaxSize()) {
            val c = Color.White.copy(alpha = 0.5f)
            for (i in 1..2) {
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width * i / 3, 0f),
                    androidx.compose.ui.geometry.Offset(size.width * i / 3, size.height), 2f)
                drawLine(c, androidx.compose.ui.geometry.Offset(0f, size.height * i / 3),
                    androidx.compose.ui.geometry.Offset(size.width, size.height * i / 3), 2f)
            }
        }

        if (countdown > 0) Text(
            "$countdown", color = Color.White, fontSize = 96.sp, modifier = Modifier.align(Alignment.Center)
        )

        // bar atas
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Chip(when (flash) {
                ImageCapture.FLASH_MODE_ON -> "Flash ON"
                ImageCapture.FLASH_MODE_AUTO -> "Flash AUTO"
                else -> "Flash OFF"
            }) {
                flash = when (flash) {
                    ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            }
            Chip(if (ratio == AspectRatio.RATIO_4_3) "4:3" else "16:9") {
                ratio = if (ratio == AspectRatio.RATIO_4_3) AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3
            }
            Chip(if (timer == 0) "Timer OFF" else "Timer ${timer}s") {
                timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 }
            }
            Chip(if (grid) "Grid ON" else "Grid OFF") { grid = !grid }
        }

        // bar bawah
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val range = camera?.cameraInfo?.exposureState?.exposureCompensationRange
            val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
            if (!pro && range != null && range.upper > range.lower) {
                Slider(
                    value = exposure,
                    onValueChange = {
                        exposure = it
                        camera?.cameraControl?.setExposureCompensationIndex(it.toInt())
                    },
                    valueRange = range.lower.toFloat()..range.upper.toFloat(),
                    modifier = Modifier.fillMaxWidth(0.7f)
                )
                Text("EV %.1f".format(exposure * step), color = Color.White, fontSize = 12.sp)
            }
            if (pro && ranges != null) {
                Column(
                    Modifier.fillMaxWidth().background(Color(0x99000000), RoundedCornerShape(12.dp)).padding(8.dp)
                ) {
                    ProRow("ISO", "${isoOf(ranges, isoV)}", isoV, 0f..1f) { isoV = it }
                    ProRow("Shutter", "1/${SHUTTERS[shutIdx]}", shutIdx.toFloat(),
                        0f..SHUTTERS.lastIndex.toFloat(), SHUTTERS.size - 2) { shutIdx = it.toInt() }
                    if (ranges.minFocus > 0f) Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(60.dp)) { Chip(if (mf) "MF" else "AF") { mf = !mf } }
                        Slider(focusV, { focusV = it }, Modifier.weight(1f), enabled = mf)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        WB_NAMES.forEachIndexed { i, n ->
                            Text(n, color = if (i == wb) Color.Yellow else Color.White, fontSize = 12.sp,
                                modifier = Modifier.clickable { wb = i }.padding(6.dp))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Text("FOTO", color = if (!videoMode) Color.Yellow else Color.White,
                    modifier = Modifier.clickable(enabled = recording == null) { videoMode = false })
                Text("VIDEO", color = if (videoMode) Color.Yellow else Color.White,
                    modifier = Modifier.clickable(enabled = recording == null) { videoMode = true })
                if (ranges != null) Text("PRO", color = if (pro) Color.Cyan else Color.White,
                    modifier = Modifier.clickable { pro = !pro })
                if (st != null) Text("STAB", color = if (stab) Color.Cyan else Color.White,
                    modifier = Modifier.clickable { stab = !stab })
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.width(64.dp))
                Box(
                    Modifier.size(76.dp).border(4.dp, Color.White, CircleShape).padding(8.dp)
                        .background(if (videoMode || recording != null) Color.Red else Color.White, CircleShape)
                        .clickable { shutter() }
                )
                Chip("Putar") {
                    if (recording == null)
                        lens = if (lens == CameraSelector.LENS_FACING_BACK)
                            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
                }
            }
        }
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 12.sp,
        modifier = Modifier.background(Color(0x66000000), CircleShape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)
    )
}


// ---------- Mode Pro (Camera2 interop) ----------
private class ProRanges(val iso: IntRange, val exp: LongRange, val minFocus: Float)

private val SHUTTERS = intArrayOf(4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4, 2)
private val WB_NAMES = listOf("Auto", "Pijar", "Neon", "Siang", "Mendung")
private val WB_MODES = intArrayOf(
    CaptureRequest.CONTROL_AWB_MODE_AUTO,
    CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
    CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
    CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
    CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
)

private fun proRanges(camera: Camera): ProRanges? {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val iso = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: return null
    val exp = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return null
    val focus = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    return ProRanges(iso.lower..iso.upper, exp.lower..exp.upper, focus)
}

private fun isoOf(r: ProRanges, v: Float): Int =
    (r.iso.first * (r.iso.last.toFloat() / r.iso.first).pow(v)).toInt().coerceIn(r.iso.first, r.iso.last)

private class StabInfo(val eis: Boolean, val ois: Boolean)

private fun stabInfo(camera: Camera): StabInfo? {
    val info = Camera2CameraInfo.from(camera.cameraInfo)
    val eis = info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        ?.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
    val ois = info.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        ?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
    return if (eis || ois) StabInfo(eis, ois) else null
}

private fun applyPro(
    camera: Camera, r: ProRanges?, on: Boolean,
    isoV: Float, shutIdx: Int, wb: Int, mf: Boolean, focusV: Float,
    stab: Boolean, st: StabInfo?
) {
    val ctl = Camera2CameraControl.from(camera.cameraControl)
    val b = CaptureRequestOptions.Builder()
    var any = false
    if (stab && st != null) {
        // EIS dan OIS tidak dinyalakan bersamaan: pakai EIS jika ada, kalau tidak OIS
        if (st.eis) b.setCaptureRequestOption(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        else b.setCaptureRequestOption(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        any = true
    }
    if (on && r != null) {
        val ns = (1_000_000_000L / SHUTTERS[shutIdx]).coerceIn(r.exp.first, r.exp.last)
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, isoOf(r, isoV))
        b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, WB_MODES[wb])
        if (mf && r.minFocus > 0f) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusV * r.minFocus)
        }
        any = true
    }
    if (any) ctl.setCaptureRequestOptions(b.build()) else ctl.clearCaptureRequestOptions()
}

@Composable
private fun ProRow(
    label: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>,
    steps: Int = 0, onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.width(60.dp))
        Slider(value = v, onValueChange = onChange, modifier = Modifier.weight(1f), valueRange = range, steps = steps)
        Text(value, color = Color.Yellow, fontSize = 12.sp, modifier = Modifier.width(56.dp))
    }
}
